#ifndef KQUEUE_EVENT_HANDLER_H
#define KQUEUE_EVENT_HANDLER_H

#include "../Queue.h"
#include <queue>
#include <map>


class KqueueService {
public:
  KqueueService(EventQueue &queue, std::string path);

  std::string getError();
  bool hasErrored();
  bool isWatching();

  ~KqueueService();
private:
  int instance;
};

#endif

#include "../../includes/bsd/KqueueService.h"

KqueueService::KqueueService(EventQueue &queue, std::string path) {
  ;
}

KqueueService::~KqueueService() {
  ;
}

std::string KqueueService::getError() {
  return "";
}

bool KqueueService::hasErrored() {
  return false;
}

bool KqueueService::isWatching() {
  return false;
}
